$(function (){
    Kakao.Auth.authorize({
        redirectUri: 'http://192.168.2.22:5500/src/main/webapp/project_html/kakao.html'
    })
})